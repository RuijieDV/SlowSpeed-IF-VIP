# vip_uvm
jtag vip in uvm
used with minsoc project
